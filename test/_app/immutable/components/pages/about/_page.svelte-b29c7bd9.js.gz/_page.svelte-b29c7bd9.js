import{S,i as P,s as V,l as h,a as g,u as w,L as z,m,h as o,c as b,p,v as _,q as k,C as t,b as M,n as x}from"../../../chunks/index-1a171785.js";function B(O){let n,d,e,r,u,f,i,y,v,l,I;return{c(){n=h("meta"),d=g(),e=h("div"),r=h("h1"),u=w("About Me"),f=g(),i=h("p"),y=w(`I am a full-stack developer with experience in a variety of technologies, I am always determined
		to learn new techniques and technologies to enhance how I approach new problems and
		requirements. I am not currently searching for a role but I am open to ones that can continue to
		challenge my knowledge and help me build my experiences.`),v=g(),l=h("p"),I=w(`Software development is a hobby for me, I attend hackathons and meetups run by companies such as
		Intuit and OVO Energy and have taken part in international competitions such as EuroBot. In my
		spare time, other than running and socializing, I like to learn new languages and frameworks to
		help me diversify how I think of problems.`),this.h()},l(a){const c=z('[data-svelte="svelte-px9xo7"]',document.head);n=m(c,"META",{name:!0,content:!0}),c.forEach(o),d=b(a),e=m(a,"DIV",{class:!0});var s=p(e);r=m(s,"H1",{});var E=p(r);u=_(E,"About Me"),E.forEach(o),f=b(s),i=m(s,"P",{});var q=p(i);y=_(q,`I am a full-stack developer with experience in a variety of technologies, I am always determined
		to learn new techniques and technologies to enhance how I approach new problems and
		requirements. I am not currently searching for a role but I am open to ones that can continue to
		challenge my knowledge and help me build my experiences.`),q.forEach(o),v=b(s),l=m(s,"P",{});var A=p(l);I=_(A,`Software development is a hobby for me, I attend hackathons and meetups run by companies such as
		Intuit and OVO Energy and have taken part in international competitions such as EuroBot. In my
		spare time, other than running and socializing, I like to learn new languages and frameworks to
		help me diversify how I think of problems.`),A.forEach(o),s.forEach(o),this.h()},h(){document.title="About Me",k(n,"name","description"),k(n,"content","About me"),k(e,"class","content")},m(a,c){t(document.head,n),M(a,d,c),M(a,e,c),t(e,r),t(r,u),t(e,f),t(e,i),t(i,y),t(e,v),t(e,l),t(l,I)},p:x,i:x,o:x,d(a){o(n),a&&o(d),a&&o(e)}}}class D extends S{constructor(n){super(),P(this,n,null,B,V,{})}}export{D as default};
