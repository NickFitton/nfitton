import{default as r}from"../components/error.svelte-dcc57ee3.js";import"./index-1a171785.js";import"./stores-2f16a0cd.js";export{r as component};
