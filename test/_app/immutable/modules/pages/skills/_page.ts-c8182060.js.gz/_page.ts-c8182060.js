import"../../../chunks/index-1a171785.js";import"../../../chunks/SkillCard.svelte_svelte_type_style_lang-bbc3f07d.js";import{p as m}from"../../../chunks/_page-badce4c9.js";export{m as prerender};
