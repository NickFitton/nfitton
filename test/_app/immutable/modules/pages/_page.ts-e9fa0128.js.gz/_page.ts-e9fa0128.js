import{p}from"../../chunks/_page-802cc2a3.js";export{p as prerender};
