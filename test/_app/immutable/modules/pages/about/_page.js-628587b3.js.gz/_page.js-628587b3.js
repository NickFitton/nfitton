import"../../../chunks/env-78bc2080.js";import{h as o,p,r as t}from"../../../chunks/_page-06db4afc.js";export{o as hydrate,p as prerender,t as router};
