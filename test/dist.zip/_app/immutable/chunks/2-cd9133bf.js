import{_ as t}from"./_page-802cc2a3.js";import{default as m}from"../components/pages/_page.svelte-ce0de081.js";import"./index-1a171785.js";export{m as component,t as shared};
