const s=!0,e=!1;export{s as b,e as d};
